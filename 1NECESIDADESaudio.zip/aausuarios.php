<!DOCTYPE html>
<!--
Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHPWebPage.php to edit this template
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
$usuarios = array(
    'u' => password_hash('c', PASSWORD_DEFAULT),
    'uu' => password_hash('cc', PASSWORD_DEFAULT),
);
?>
    </body>
</html>
