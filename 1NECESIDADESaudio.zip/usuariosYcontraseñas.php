<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
$usuarios = array(
    'us' => password_hash('co', PASSWORD_DEFAULT),
    'uu' => password_hash('cc', PASSWORD_DEFAULT),
);
?>
    </body>
</html>
