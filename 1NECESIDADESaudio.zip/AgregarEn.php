<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    
    <style>
.tabla1 {
width:100%;
height:184px;
}
.img1{
width:1200px;
height:184px;   
}


.tabla2 {
width: 100%;
height: 241px;
}
.img2p1{
width:146px;
height:80px;
}
.img2p2{
width:590px;
height:258px;
}
.img2p3{
width:298px;
height:80px;
}

        
.tabla3 {
width: 500px;
height: 80px;
}
.img3{
width: 298px;
height: 80px;          
}        
    </style>
</head>
<body>

<table class="tabla1">
  <tr>
    <td>
        <img class="img1" src="PECSimagen/pecs.png">
    </td>
  </tr>
 </table>    
  
    
     
<table class="tabla2">    
<tr>
    
    
    
<td>
  <div style="display: flex;">
    <div style="flex: 1;">
      <a href="index.php">
      <img class="img2p1" src="PECSimagen/CASA.png">
      </a>
    </div>
                
    <div style="flex: 1;">
      <a href="dialogos.php">  
      <img class="img2p1" src="PECSimagen/VOLVER A DIALOGAR.png">
      </a>
    </div>
  </div>
</td>





<td rowspan="3" class="td3">
   <img class="img2p2" src="PECSimagen/AGREGA IMAGEN Y AUDIO.png">  
</td>
        
<td>
    <a href="AGREGARen1NECESIDADES.php">
    <img class="img2p3" src="PECSimagen/1NECESIDADES.png">
    </a>
</td>
</tr>  





<tr>    
      <td>
         <a href="AGREGARen2ALIMENTOS.php">
         <img class="img2p3" src="PECSimagen/2ALIMENTOS.png">
         </a>
      </td>
       
      <td style="background-color: green;width: 200px;">
        <a href="AGREGARen3ESCUELA.php">  
        <img class="img2p3" src="PECSimagen/3COLEGIO.png">
        </a>
      </td> 
</tr>

<tr>
    
    <td>
    <a href="AGREGARen4ACTIVIDADES.php">
    <img class="img2p3" src="PECSimagen/4ACTIVIDADES.png">
    </a>
    </td>
    
    
    <td>
    <a href="AGREGARen5ROPAS.php">
    <img class="img2p3" src="PECSimagen/5ROPAS.png">
    </a>
    </td> 
</tr>
</table>  

    
    
    
    
<table class="tabla3">
   <tr>
      <td>
      <a href="AGREGARen6HIGIENE.php">    
      <img class="img3" src="PECSimagen/6HIGIENE.png">
      </a>
      </td>
      
     
      <td>
      <a href="AGREGARen7CUERPO.php">  
      <img class="img3" src="PECSimagen/7CUERPO.png">
      </a>
      </td>
      
      <td>
      <a href="AGREGARen8ANIMALES.php">
      <img class="img3" src="PECSimagen/8ANIMALES.png">
      </a>
      </td>
      <td>
      <a href="AGREGARen9OTROS.php">
      <img class="img3" src="PECSimagen/9OTROS.png">
      </a>
      </td>
    </tr>
</table>