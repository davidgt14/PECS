        <?php
$usuarios = array(
    'u' => password_hash('c', PASSWORD_DEFAULT),
    'uu' => password_hash('cc', PASSWORD_DEFAULT),
);
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>

    </body>
</html>
